/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchat2;

import java.util.Scanner;

/**
 *
 * @author Monga
 */
public class QuickChat2 {

    static String storedUsername;
    static String storedPassword;
    static String storedCellPhone;
    
    static Scanner input = new Scanner(System.in);

    public static boolean checkUsername(String username) {
        return username.length() >= 5;
    }

    public static boolean checkPassword(String password) {
        boolean hasNumber = password.matches(".*\\d.*");
        boolean hasSpecial = password.matches(".*[^a-zA-Z0-9].*");

        return password.length() >= 8
                && hasNumber
                && hasSpecial;
    }

    public static boolean checkCellPhone(String phone) {
        return phone.startsWith("+27")
                && phone.length() == 12;
    }

    public static void register() {

        System.out.println("===== REGISTER =====");

        System.out.print("Enter username: ");
        String username = input.nextLine();

        System.out.print("Enter password: ");
        String password = input.nextLine();

        System.out.print("Enter phone number (+27...): ");
        String phone = input.nextLine();

        if (checkUsername(username)
                && checkPassword(password)
                && checkCellPhone(phone)) {

            storedUsername = username;
            storedPassword = password;

            System.out.println("Registration successful!");

        } else {

            System.out.println("Registration failed.");
            System.exit(0);
        }
    }

    public static boolean login() {
        
        System.out.println("\n===== LOGIN =====");

        System.out.print("Enter username: ");
        String username = input.nextLine();

        System.out.print("Enter password: ");
        String password = input.nextLine();

        if (username.equals(storedUsername)
                && password.equals(storedPassword)) {

            System.out.println("Login successful!");
            return true;
        }

        System.out.println("Login failed!");
        return false;
    }

    public static void main(String[] args) {

        register();

        if (login()) {

            System.out.println("Welcome to QuickChat");

            System.out.print("How many messages would you like to send? ");
            int totalMessages = input.nextInt();
            input.nextLine();

            int choice = 0;

            while (choice != 3) {

                System.out.println("\n===== MENU =====");
                System.out.println("1. Send Messages");
                System.out.println("2. Show recently sent messages");
                System.out.println("3. Quit");
                System.out.println("4. Stored Messages");

                System.out.print("Choose option: ");
                choice = input.nextInt();
                input.nextLine();

                switch (choice) {

                    case 1 -> {
                        int messageCounter = 0;
                            if (messageCounter >= totalMessages) {
                                System.out.println("Message limit reached.");
                            }
                            
                            System.out.print("Enter recipient number: ");
                            String recipient = input.nextLine();
                            
                            System.out.print("Enter message: ");
                            String message = input.nextLine();
                            
                            if (message.length() >250) {
                                
                                System.out.println("Please enter a message of less than 250 characters");
                            }
                            
                            Message msg = new Message(messageCounter + 1, recipient, message);
                            
                            System.out.println(msg.checkRecipientNumber());
                            
                            if (msg.checkMessageID()) {
                                System.out.println("Invalid Message.");
                            }
                            
                            System.out.println("Message Hash: " + msg.getMessageHash());
                            
                            String result = msg.SentMessage();
                            
                            System.out.println(result);
                            
                            if (result.equals("Message succesfully sent")) {
                                
                                messageCounter++;
                                
                                System.out.println(msg.printMessages());
                                
                                System.out.println("\nTotal Messages Sent: " + msg.returnTotalMessages());
                            }
                        }

                            
                        case 2 -> System.out.println("Coming Soon.");
                            
                        case 3 -> System.out.println("Thank you for using QuickChat.");
                        
                        case 4 -> storedMessagesMenu();
                            
                        default -> System.out.println("Invalid option.");
                    }
                }
                
            } else {
                
                System.out.println("Login Failed.");
            }
        }

    private static void storedMessagesMenu() {
        
        System.out.println("\n=== STORED MESSAGES ===");
        System.out.println("1. Display sender and recipient");
        System.out.println("2. Display longest stored message");
        System.out.println("3. Search by Message ID");
        System.out.println("4. Search by Recipient");
        System.out.println("5. Delete by Message Hash");
        System.out.println("6. Display Full Report");
    }
}

