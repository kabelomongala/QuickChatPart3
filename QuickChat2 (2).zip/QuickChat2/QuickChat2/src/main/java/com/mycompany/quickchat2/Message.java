/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quickchat2;

import java.util.Random;
import java.util.Scanner;
import java.util.ArrayList;
/**
 *
 * @author Monga
 */
public final class Message {

    String messageID;
    int messageNumber;
    String recipient;
    String message;
    String messageHash;
    
    public static ArrayList<String> sentMessages = new ArrayList<>();
    public static ArrayList<String> disregardedMessages = new ArrayList<>();
    public static ArrayList<String> storedMessages = new ArrayList<>();
    public static ArrayList<String> messageHashes = new ArrayList<>();
    public static ArrayList<String> messageIDs = new ArrayList<>();

public static ArrayList<String> recipients = new ArrayList<>();
    
    private static int totalMessages = 0;
    
    public Message(int messageNumber, String recipient, String message) {
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.message = message;
        this.messageID = generateMessageID();
        this.messageHash = createMessageHash();
    }
    
    private String generateMessageID() {
        Random random = new Random();
        long id = 1000000000L +
                (long)(random.nextDouble() * 9000000000L);
        
        return String.valueOf(id);
    }
    
    public boolean checkMessageID() {
        return messageID.length() <=10;
    }
    
    public String checkRecipientNumber() {
        
        if (recipient.startsWith("+27") && recipient.length() <=13) {
            
            return "Cell phone number successfully captured.";
        }
        
        return "Cell phonr number incorrectly formatted.";
    }
    
    public String createMessageHash() {
        
        String[] words = message.trim().split("\\s+");
        
        String firstWord = words[0].toUpperCase();
        String lastWord = words[words.length - 1].toUpperCase();
        
        return messageID.substring(0, 2)
                + ":"
                + messageNumber
                + firstWord
                + lastWord;
    }
    
    public String SentMessage() {
        
        Scanner input = new Scanner(System.in);
        
        System.out.println("Choose an option: ");
        System.out.println("1. Send Message");
        System.out.println("2. Store Message");
        System.out.println("0. Disregard Message");
        
        int choice = input.nextInt();
        
        switch (choice) {
            
            case 1 -> {
                totalMessages++;
                return "Message successfully sent";
            }
                
            case 2 -> {
                storeMessage();
                return "Message successfully stored";
            }
                
            case 0 -> {
                return "Press ) to delete the message";
            }
                
            default -> {
                return "Invalid option";
            }
        }
    }
    
    public String printMessages() {
        
        return"Message ID:" + messageID
                + "Message Hash: " + messageHash
                + "Recipient:" + recipient
                + "Message: " + message;
    }
    
    public int returnTotalMessages() {
        return totalMessages;
    }    
    
    public void storeMessages() {
        System.out.println("Message stored successfully.");
    }
    
    public String getMessageID() {
        return messageID;
    }
    
    /**
     *
     * @return
     */
    public String getMessageHash() {
        return messageHash;
    }

    private void storeMessage() {
        
        System.out.println("\n=== STORED MESSAGES ===");

        for (int i = 0; i < storedMessages.size(); i++) {
            
            System.out.println("Recipient: " + recipients.get(i));
            System.out.println("Message: " + storedMessages.get(i));
            System.out.println("--------------------");
        }
    }
      
    public static void displayLongestMessage() {
        
        if (storedMessages.isEmpty()) {
            System.out.println("No stored messages.");
            return;
        }
    
        String longest = storedMessages.get(0);
        
        for (String msg : storedMessages) {
            
            if (msg.length() > longest.length()) {
                longest = msg;
            }
        }
        
         System.out.println("Longest stored message:");
         System.out.println(longest);
    }
    
    public static void searchMessageID(String id) {
        
        int index = messageIDs.indexOf(id);
        
        if (index != -1) {
            
            System.out.println("Recipient: " + recipients.get(index));
            System.out.println("Message: " + sentMessages.get(index));
            
        } else {
        
            System.out.println("Message ID not found.");
        }
    }
    
    public static void searchRecipient(String recipient) {
        
        boolean found = false;
        
        for (int i = 0; i < recipients.size(); i++) {
            
            if (recipients.get(i).equals(recipient)) {
                
                found = true;
                
                if (i < sentMessages.size()) {
                    System.out.println(sentMessages.get(i));
                }    
                
                if (i < storedMessages.size()) {
                    System.out.println(storedMessages.get(i));
                }    
            }
        }
        
        if (!found) {
            System.out.println("No messages found.");
        }
    }

    public static void deleteByHash(String hash) {
        
        int index = messageHashes.indexOf(hash);

        if (index != -1) {
            
            messageHashes.remove(index);
            
            if (index < sentMessages.size()) {
                sentMessages.remove(index);
            }
        
            System.out.println("Message deleted.");
            
        } else {
            
            System.out.println("Hash not found.");
        }
    }
    
    public static void displayReport() {
        
        System.out.println("\n===== MESSAGE REPORT =====");
        
        for (int i = 0; i < sentMessages.size(); i++) {
            
            System.out.println("Message ID: " + messageIDs.get(i));
            System.out.println("Hash: " + messageHashes.get(i));
            System.out.println("Recipient: " + recipients.get(i));
            System.out.println("Message: " + sentMessages.get(i));
            System.out.println("-------------------------");
        }
    }
}