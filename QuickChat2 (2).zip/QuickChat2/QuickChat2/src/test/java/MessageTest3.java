/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.quickchat2.Message;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Monga
 */
public class MessageTest3 {
    
    @Test
    public void testMessagesArray() {
        
        Message.sentMessages.clear();
        
        Message.sentMessages.add("Did you get the cake?");
        Message.sentMessages.add("It is dinner time!");
        
        assertEquals("Did you get the cake?", Message.sentMessages.get(0));
    }
    
    @Test
    public void testLongestStoredMessage() {
        
        Message.storedMessages.clear();
        
        Message.storedMessages.add("Did you get the cake?");
        Message.storedMessages.add("Where are you? You are late! I have asked you to be on time.");
        
        String longest = Message.storedMessages.get(1);
        
        assertEquals("Where are you? You are late! I have asked you to be on time.", longest);
    }
    
    @Test
    public void testSearchRecipient() {
        
        Message.storedMessages.clear();
        Message.recipients.clear();
        
        Message.recipients.add("+27838884567");
        Message.storedMessages.add("Where are you? You are late! I have asked you to be on time.");
        
        Message.recipients.add("+27838884567");
        Message.storedMessages.add("Ok, I am leaving without you.");
        
        int count = 0;
        
        for(String r : Message.recipients) {
            
            if(r.equals("+27838884567")) {
                count++;        
            }
        }
    
        assertEquals(2, count);
    }
    
    @Test
    public void testDeleteMessageByHash() {
        
        Message.messageHashes.clear();
        
        Message.messageHashes.add("HASH001");
        Message.messageHashes.add("HASH002");
        
        Message.messageHashes.remove("HASH002");
        
        assertFalse(Message.messageHashes.contains("HASH002"));
    }
    
    @Test
    public void testDisplayReportData() {
        
        Message.sentMessages.clear();
        Message.recipients.clear();
        
        Message.sentMessages.add("Did you get the cake?");
        Message.recipients.add("+27834557896");
        
        assertEquals(1, Message.sentMessages.size());
        
        assertEquals("+27834557896", Message.recipients.get(0));
    }
}

