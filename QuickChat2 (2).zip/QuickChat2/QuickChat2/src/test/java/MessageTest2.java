
import com.mycompany.quickchat2.Message;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */


/**
 *
 * @author Monga
 */
public class MessageTest2 {
    
    @Test
    public void testValidUsername() {

        assertTrue(QuickChat.checkUsername("kyl_1"));
    }

    @Test
    public void testInvalidUsername() {

        assertFalse(QuickChat.checkUsername("kyle"));
    }

    @Test
    public void testValidPassword() {

        assertTrue(QuickChat.checkPassword("Ch&&sec@ke99!"));
    }

    @Test
    public void testInvalidPasswordNoSpecialCharacter() {

        assertFalse(QuickChat.checkPassword("Password1"));
    }

    @Test
    public void testInvalidPasswordTooShort() {

        assertFalse(QuickChat.checkPassword("password"));
    }

    @Test
    public void testValidCellPhoneNumber() {

        assertTrue(QuickChat.checkCellPhone("+27838968976"));
    }

    @Test
    public void testInvalidCellPhoneNumber() {

        assertFalse(QuickChat.checkCellPhone("08966553"));
    }
    
    @Test
    public void testMessageLengthSucess() {
        
        String message = "Hi Mike, can you join us for dinner tonight?";
        
        assertTrue(message.length() <=250);
    }
    
    @Test
    public void testMessageLengthFailure() {
        
        String message = "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk";
    
        assertTrue(message.length() >250);
    }
    
    @Test
    public void testRecipientSuccess() {
        
        Message msg = new Message(1, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        
    assertEquals("Cell phone number successfully captured.", msg.checkRecipientNumber());
    }
    
    @Test
    public void testRecipientFailure() {
        
        Message msg = new Message(2, "08575975889", "Hi Keegan, did you receive the payment?");
    
        assertEquals("Cell phone number incorrectly formatted.", msg.checkRecipientNumber());
    }
    
    @Test
    public void testMessageIDCreated() {
        
        Message msg = new Message(1, "+27718693002", "Hello");
        
        assertNotNull(msg.getMessageID());
    }
    
    @Test
    public void testMessageIDLength() {
        
        Message msg = new Message(1, "+27718693002", "Hello");
        
        assertTrue(msg.checkMessageID());
    }
    
    @Test
    public void testHashCreated() {
        
        Message msg = new Message(1, "+27718693002", "Hi Mike can you join us for dinner");
        
        String hash = msg.createMessageHash();
        
        assertNotNull(hash);
    }
    
    @Test
    public void testPrintMessages() {
        
         Message msg = new Message(1, "+27718693002", "Hi Mike can you join us for dinner?");
         
         assertNotNull(msg.printMessages());
    }
    
    @Test
    public void testReturnTotalMessages() {
        
        Message msg = new Message(1, "+27718693002", "Hello");
        
        int total = msg.returnTotalMessages();
        
        assertTrue(total >=0);
    }
}  