
import com.mycompany.quickchat2.Message;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Monga
 */
class QuickChat {
    
    public static void loadTestData() {
        
        Message.sentMessages.add("Did you get the cake?");
        Message.recipients.add("+27834557896");
        
        Message.storedMessages.add("Where are you? You are late! I have asked you to be on time.");
        Message.recipients.add("+27838884567");
        
        Message.disregardedMessages.add("Yohoooo, I am at your gate.");
        Message.recipients.add("+27834484567");

        Message.sentMessages.add("It is dinner time!");
        Message.recipients.add("0838884567");
        
        Message.storedMessages.add("Ok, I am leaving without you.");
        Message.recipients.add("+27838884567");
    }

    static boolean checkUsername(String kyl_1) {
        return false;
    }

    static boolean checkPassword(String chsecke99) {
        return false;
    }

    static boolean checkCellPhone(String string) {
        return false;
    }
    
}
